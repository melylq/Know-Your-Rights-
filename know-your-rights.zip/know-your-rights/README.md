# Know Your Rights

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Mely35/pen/01a0a1f7-e7ec-7fc9-b30f-63736d144895](https://codepen.io/editor/Mely35/pen/01a0a1f7-e7ec-7fc9-b30f-63736d144895).

